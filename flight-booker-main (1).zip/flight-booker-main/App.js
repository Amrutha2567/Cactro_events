import React from 'react';
import FlightBooker from './FlightBooker';

function App() {
  return (
    <div>
      <FlightBooker />
    </div>
  );
}

export default App;
